$begin 'Profile'
	$begin 'ProfileGroup'
		MajorVer=2025
		MinorVer=2
		Name='Solution Process'
		$begin 'StartInfo'
			I(1, 'Start Time', '11/01/2026 05:40:30')
			I(1, 'Host', 'n113.hpc')
			I(1, 'Processor', '256')
			I(1, 'OS', 'Linux 4.18.0-553.5.1.el8_10.x86_64')
			I(1, 'Product', 'Maxwell2D 2025.2.0')
		$end 'StartInfo'
		$begin 'TotalInfo'
			I(1, 'Elapsed Time', '00:15:01')
			I(1, 'ComEngine Memory', '101 M')
		$end 'TotalInfo'
		GroupOptions=8
		TaskDataOptions(Memory=8)
		ProfileItem('', 0, 0, 0, 0, 0, 'I(1, 1, \'Executing From\', \'/opt/ohpc/pub/Electronics/v252/AnsysEM/MAXWELL2DCOMENGINE.exe\')', false, true)
		$begin 'ProfileGroup'
			MajorVer=2025
			MinorVer=2
			Name='HPC'
			$begin 'StartInfo'
				I(1, 'Type', 'Manual')
				I(1, 'Distribution Types', 'Variations, Frequencies, Domain Solver, Transient Excitations, Direct Solver, Iterative Solver, Solver, Mesh Assembly, Mesher')
				I(1, 'MPI Vendor', 'Intel')
				I(1, 'MPI Version', '2021')
			$end 'StartInfo'
			$begin 'TotalInfo'
				I(0, ' ')
			$end 'TotalInfo'
			GroupOptions=0
			TaskDataOptions(Memory=8)
			ProfileItem('Machine', 0, 0, 0, 0, 0, 'I(4, 1, \'Name\', \'nib113.hpc\', 3, \'RAM Limit\', 90, \'%f%%\', 2, \'Tasks\', 1, false, 2, \'Cores\', 4, false)', false, true)
		$end 'ProfileGroup'
		ProfileItem('Design Validation', 0, 0, 0, 0, 0, 'I(3, 1, \'Level\', \'Perform full validations\', 1, \'Elapsed Time\', \'00:00:00\', 2, \'Memory\', 101816, true)', false, true)
		$begin 'ProfileGroup'
			MajorVer=2025
			MinorVer=2
			Name='Initial Meshing'
			$begin 'StartInfo'
				I(1, 'Time', '11/01/2026 05:40:30')
			$end 'StartInfo'
			$begin 'TotalInfo'
				I(1, 'Elapsed Time', '00:00:00')
			$end 'TotalInfo'
			GroupOptions=4
			TaskDataOptions(Memory=8)
			ProfileItem('Mesh', 0, 0, 0, 0, 71000, 'I(2, 1, \'Type\', \'TAU(2D)\', 2, \'Triangles\', 4162, false)', true, true)
			ProfileItem('  Manual Refine', 0, 0, 0, 0, 174104, 'I(2, 2, \'Triangles\', 9828, false, 0, \'Mesh_band, Mesh_magnet, Mesh_rotor, Mesh_stator, Mesh_winding\')', true, true)
		$end 'ProfileGroup'
		$begin 'ProfileGroup'
			MajorVer=2025
			MinorVer=2
			Name='Transient Solution'
			$begin 'StartInfo'
				I(1, 'Time', '11/01/2026 05:40:31')
			$end 'StartInfo'
			$begin 'TotalInfo'
				I(1, 'Elapsed Time', '00:15:00')
			$end 'TotalInfo'
			GroupOptions=4
			TaskDataOptions(Memory=8)
			ProfileItem('HPC Settings', 0, 0, 0, 0, 0, 'I(1, 2, \'Cores\', 4, false)', false, true)
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 13441, 'I(5, 1, \'Type\', \'DRA\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 15, false)', true, true)
				ProfileItem('  Solve', 0, 0, 2, 0, 235136, 'I(1, 3, \'Final Residual\', 4.44129e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 242336, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 4.16666666666667e-05s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8510, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 5, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 257160, 'I(1, 3, \'Final Residual\', 3.13571e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 257880, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 8.33333333333333e-05s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8625, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 9, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 258992, 'I(1, 3, \'Final Residual\', 8.19254e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 258996, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.000125s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8452, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 9, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 259672, 'I(1, 3, \'Final Residual\', 1.68771e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 260052, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.000166666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8756, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 9, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 260056, 'I(1, 3, \'Final Residual\', 1.69958e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 260196, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.000208333333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8689, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 9, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 260344, 'I(1, 3, \'Final Residual\', 1.61807e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 260488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00025s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8509, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 9, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 260500, 'I(1, 3, \'Final Residual\', 1.53579e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 260504, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.000291666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8544, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 260756, 'I(1, 3, \'Final Residual\', 1.44688e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 260756, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.000333333333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8479, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 260756, 'I(1, 3, \'Final Residual\', 1.38146e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 260796, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.000375s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8713, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 260872, 'I(1, 3, \'Final Residual\', 1.34319e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 260872, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.000416666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8478, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 260876, 'I(1, 3, \'Final Residual\', 1.35403e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 260876, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.000458333333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8550, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 260876, 'I(1, 3, \'Final Residual\', 1.45041e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 260924, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0005s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8463, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 9, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 260924, 'I(1, 3, \'Final Residual\', 1.76663e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 260924, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.000541666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8690, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 260924, 'I(1, 3, \'Final Residual\', 2.62943e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 260976, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.000583333333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8469, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 260976, 'I(1, 3, \'Final Residual\', 2.07781e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 260976, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.000625s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8495, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 260976, 'I(1, 3, \'Final Residual\', 2.54123e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 260976, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.000666666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 3, 0, 8608, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 260976, 'I(1, 3, \'Final Residual\', 3.14929e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 260976, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.000708333333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8408, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 260976, 'I(1, 3, \'Final Residual\', 3.61164e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 260976, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00075s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8569, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 260980, 'I(1, 3, \'Final Residual\', 4.10305e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 260980, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.000791666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8597, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 260984, 'I(1, 3, \'Final Residual\', 4.53646e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 260988, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.000833333333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8676, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 260988, 'I(1, 3, \'Final Residual\', 4.93884e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 260988, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.000875s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8524, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 260988, 'I(1, 3, \'Final Residual\', 5.30086e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 261244, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.000916666666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 3, 0, 8587, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 261244, 'I(1, 3, \'Final Residual\', 5.86417e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 261252, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.000958333333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8418, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 261268, 'I(1, 3, \'Final Residual\', 6.10205e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 261332, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8452, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 261444, 'I(1, 3, \'Final Residual\', 6.28311e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 261444, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00104166666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8337, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 261444, 'I(1, 3, \'Final Residual\', 6.2718e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 261480, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00108333333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8728, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 261480, 'I(1, 3, \'Final Residual\', 6.38071e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 261480, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.001125s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8513, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 261480, 'I(1, 3, \'Final Residual\', 5.82085e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 261480, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00116666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 2, 0, 8354, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 261488, 'I(1, 3, \'Final Residual\', 2.33148e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 261488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00120833333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8513, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 261488, 'I(1, 3, \'Final Residual\', 7.37425e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 261488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00125s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8550, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 261488, 'I(1, 3, \'Final Residual\', 7.53266e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 261488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00129166666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8471, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 261548, 'I(1, 3, \'Final Residual\', 1.84172e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 261548, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00133333333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8508, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 261548, 'I(1, 3, \'Final Residual\', 7.00167e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 261552, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.001375s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8576, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 261580, 'I(1, 3, \'Final Residual\', 5.88676e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 261580, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00141666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8288, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 261584, 'I(1, 3, \'Final Residual\', 6.01094e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 261584, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00145833333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8362, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 261584, 'I(1, 3, \'Final Residual\', 6.09559e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 261584, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0015s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8440, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 261584, 'I(1, 3, \'Final Residual\', 6.25249e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 261584, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00154166666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8359, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 261584, 'I(1, 3, \'Final Residual\', 6.28587e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 261584, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00158333333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8462, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 261584, 'I(1, 3, \'Final Residual\', 6.13186e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 261584, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.001625s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8307, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 261600, 'I(1, 3, \'Final Residual\', 5.89747e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 261600, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00166666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8391, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 261600, 'I(1, 3, \'Final Residual\', 5.51659e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 261600, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00170833333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8393, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 261600, 'I(1, 3, \'Final Residual\', 5.21745e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 261600, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00175s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 3, 0, 8738, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 261600, 'I(1, 3, \'Final Residual\', 4.9528e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 261600, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00179166666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8613, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 261600, 'I(1, 3, \'Final Residual\', 4.84666e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 261696, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00183333333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8531, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 261696, 'I(1, 3, \'Final Residual\', 4.66911e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 261696, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.001875s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8484, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 261696, 'I(1, 3, \'Final Residual\', 4.42242e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 261696, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00191666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8477, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 261696, 'I(1, 3, \'Final Residual\', 4.22471e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 261696, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00195833333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 3, 0, 8417, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 261696, 'I(1, 3, \'Final Residual\', 4.03487e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 261696, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.002s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8526, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 261716, 'I(1, 3, \'Final Residual\', 3.8422e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 261716, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00204166666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8339, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 261716, 'I(1, 3, \'Final Residual\', 3.67875e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 261716, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00208333333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 2, 0, 8423, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 261720, 'I(1, 3, \'Final Residual\', 3.5527e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 264632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.002125s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 3, 0, 8526, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 264704, 'I(1, 3, \'Final Residual\', 3.14262e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 264820, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00216666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8703, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 264880, 'I(1, 3, \'Final Residual\', 2.58627e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 264880, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00220833333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8684, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 264880, 'I(1, 3, \'Final Residual\', 2.19875e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 264880, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00225s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 2, 0, 8581, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 264880, 'I(1, 3, \'Final Residual\', 1.95463e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 264880, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00229166666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8389, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 264880, 'I(1, 3, \'Final Residual\', 1.78454e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 264880, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00233333333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8581, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 264880, 'I(1, 3, \'Final Residual\', 1.67355e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 264880, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.002375s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 2, 0, 8558, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 264880, 'I(1, 3, \'Final Residual\', 1.58574e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 264880, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00241666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8497, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 264880, 'I(1, 3, \'Final Residual\', 1.51177e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 264880, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00245833333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8423, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 264880, 'I(1, 3, \'Final Residual\', 1.46036e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 264880, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0025s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8573, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 264960, 'I(1, 3, \'Final Residual\', 1.5012e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 264960, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00254166666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8586, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 264960, 'I(1, 3, \'Final Residual\', 1.53397e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 264960, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00258333333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 2, 0, 8570, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 264960, 'I(1, 3, \'Final Residual\', 1.82226e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 264960, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.002625s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8610, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 264960, 'I(1, 3, \'Final Residual\', 2.76547e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 264960, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00266666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8421, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265012, 'I(1, 3, \'Final Residual\', 2.07592e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265012, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00270833333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8558, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265012, 'I(1, 3, \'Final Residual\', 2.52374e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265012, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00275s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8349, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265012, 'I(1, 3, \'Final Residual\', 3.1408e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265012, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00279166666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8579, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265012, 'I(1, 3, \'Final Residual\', 3.60428e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265012, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00283333333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8448, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265012, 'I(1, 3, \'Final Residual\', 4.10311e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265040, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.002875s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8432, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265040, 'I(1, 3, \'Final Residual\', 4.54703e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265040, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00291666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8394, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265040, 'I(1, 3, \'Final Residual\', 4.96072e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265040, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00295833333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8440, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265040, 'I(1, 3, \'Final Residual\', 5.37899e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265040, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.003s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8340, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265040, 'I(1, 3, \'Final Residual\', 5.99666e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265040, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00304166666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8330, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265040, 'I(1, 3, \'Final Residual\', 6.26095e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265040, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00308333333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8491, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265040, 'I(1, 3, \'Final Residual\', 6.47421e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265040, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.003125s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8752, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265116, 'I(1, 3, \'Final Residual\', 6.48242e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00316666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8456, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265120, 'I(1, 3, \'Final Residual\', 6.53271e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265200, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00320833333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8453, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265200, 'I(1, 3, \'Final Residual\', 1.5645e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265200, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00325s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 3, 0, 8525, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265200, 'I(1, 3, \'Final Residual\', 3.11856e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265200, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00329166666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8434, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265200, 'I(1, 3, \'Final Residual\', 8.08487e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265200, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00333333333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8601, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265212, 'I(1, 3, \'Final Residual\', 7.61468e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265224, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00337500000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8551, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265296, 'I(1, 3, \'Final Residual\', 1.79528e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265296, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00341666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8631, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265312, 'I(1, 3, \'Final Residual\', 7.08492e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265312, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00345833333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8510, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265316, 'I(1, 3, \'Final Residual\', 6.22092e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265316, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00350000000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8442, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265316, 'I(1, 3, \'Final Residual\', 6.35732e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265316, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00354166666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8416, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265316, 'I(1, 3, \'Final Residual\', 6.49613e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265316, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00358333333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8593, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265316, 'I(1, 3, \'Final Residual\', 6.68385e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265316, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00362500000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8417, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265316, 'I(1, 3, \'Final Residual\', 6.75785e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265316, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00366666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8395, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265316, 'I(1, 3, \'Final Residual\', 6.53469e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265316, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00370833333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8362, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265316, 'I(1, 3, \'Final Residual\', 6.25922e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265316, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00375000000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8535, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265316, 'I(1, 3, \'Final Residual\', 5.94313e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265316, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00379166666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8600, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265316, 'I(1, 3, \'Final Residual\', 5.51987e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265316, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00383333333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8309, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265316, 'I(1, 3, \'Final Residual\', 5.20122e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265316, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00387500000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8424, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265316, 'I(1, 3, \'Final Residual\', 5.0274e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265316, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00391666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8372, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265316, 'I(1, 3, \'Final Residual\', 4.83664e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265316, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00395833333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8370, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265316, 'I(1, 3, \'Final Residual\', 4.56981e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265316, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00400000000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8307, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265316, 'I(1, 3, \'Final Residual\', 4.34191e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265316, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00404166666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8346, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265316, 'I(1, 3, \'Final Residual\', 4.15358e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265316, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00408333333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8373, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265316, 'I(1, 3, \'Final Residual\', 3.95943e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265316, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00412500000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8369, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265316, 'I(1, 3, \'Final Residual\', 3.787e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265480, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00416666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8432, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265480, 'I(1, 3, \'Final Residual\', 3.65118e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265484, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00420833333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8602, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265484, 'I(1, 3, \'Final Residual\', 3.26804e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00425000000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8479, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265488, 'I(1, 3, \'Final Residual\', 2.73722e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00429166666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8523, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265488, 'I(1, 3, \'Final Residual\', 2.30197e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00433333333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8655, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265488, 'I(1, 3, \'Final Residual\', 2.01935e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.004375s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8576, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265488, 'I(1, 3, \'Final Residual\', 1.83511e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00441666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8536, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265488, 'I(1, 3, \'Final Residual\', 1.71515e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00445833333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8628, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265488, 'I(1, 3, \'Final Residual\', 1.62735e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0045s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8456, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265488, 'I(1, 3, \'Final Residual\', 1.55521e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00454166666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8517, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265488, 'I(1, 3, \'Final Residual\', 1.49122e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00458333333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8343, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265488, 'I(1, 3, \'Final Residual\', 1.50133e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.004625s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8549, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265488, 'I(1, 3, \'Final Residual\', 1.57325e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00466666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8518, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265488, 'I(1, 3, \'Final Residual\', 1.88673e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00470833333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8471, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265488, 'I(1, 3, \'Final Residual\', 2.77749e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00475s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8612, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265488, 'I(1, 3, \'Final Residual\', 2.12937e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00479166666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8403, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265488, 'I(1, 3, \'Final Residual\', 2.58624e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00483333333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8556, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265488, 'I(1, 3, \'Final Residual\', 3.1771e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.004875s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8307, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265488, 'I(1, 3, \'Final Residual\', 3.63935e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00491666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8515, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265488, 'I(1, 3, \'Final Residual\', 4.13747e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00495833333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8591, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265488, 'I(1, 3, \'Final Residual\', 4.58515e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.005s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8427, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265488, 'I(1, 3, \'Final Residual\', 5.01613e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00504166666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8256, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265488, 'I(1, 3, \'Final Residual\', 5.40255e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00508333333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8402, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265488, 'I(1, 3, \'Final Residual\', 5.95311e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.005125s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8542, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265488, 'I(1, 3, \'Final Residual\', 6.19763e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265636, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00516666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8631, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265636, 'I(1, 3, \'Final Residual\', 6.3924e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265636, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00520833333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8404, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265636, 'I(1, 3, \'Final Residual\', 6.39417e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265636, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00525s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8549, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265776, 'I(1, 3, \'Final Residual\', 6.46686e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265808, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00529166666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8710, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265844, 'I(1, 3, \'Final Residual\', 4.64715e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265844, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00533333333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8316, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265844, 'I(1, 3, \'Final Residual\', 2.03375e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265844, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.005375s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8417, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265844, 'I(1, 3, \'Final Residual\', 6.00886e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265844, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00541666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 2, 0, 8419, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265844, 'I(1, 3, \'Final Residual\', 5.95254e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265844, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00545833333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8565, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265844, 'I(1, 3, \'Final Residual\', 1.61251e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265844, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0055s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8584, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265844, 'I(1, 3, \'Final Residual\', 6.93101e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265844, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00554166666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 3, 0, 8526, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265844, 'I(1, 3, \'Final Residual\', 6.20041e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265844, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00558333333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8543, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265844, 'I(1, 3, \'Final Residual\', 6.36099e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265844, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.005625s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8577, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 265844, 'I(1, 3, \'Final Residual\', 6.49854e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 265844, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00566666666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8449, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266428, 'I(1, 3, \'Final Residual\', 6.69093e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266428, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00570833333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8574, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266428, 'I(1, 3, \'Final Residual\', 6.78142e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266428, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00575s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 2, 0, 8495, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266428, 'I(1, 3, \'Final Residual\', 6.65058e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266428, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00579166666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8308, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266428, 'I(1, 3, \'Final Residual\', 6.39816e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266428, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00583333333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8575, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266428, 'I(1, 3, \'Final Residual\', 6.08332e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266428, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.005875s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8462, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266428, 'I(1, 3, \'Final Residual\', 5.62142e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266428, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00591666666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8442, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266428, 'I(1, 3, \'Final Residual\', 5.30674e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266428, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00595833333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8422, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266428, 'I(1, 3, \'Final Residual\', 5.11875e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266428, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00599999999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8630, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266428, 'I(1, 3, \'Final Residual\', 4.93206e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266428, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00604166666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8564, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266480, 'I(1, 3, \'Final Residual\', 4.66387e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266480, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00608333333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8544, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266480, 'I(1, 3, \'Final Residual\', 4.41921e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266480, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00612499999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8539, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266480, 'I(1, 3, \'Final Residual\', 4.22357e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266480, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00616666666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8442, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266488, 'I(1, 3, \'Final Residual\', 4.02504e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00620833333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8543, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266488, 'I(1, 3, \'Final Residual\', 3.84794e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00624999999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8488, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266488, 'I(1, 3, \'Final Residual\', 3.70762e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00629166666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8593, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266488, 'I(1, 3, \'Final Residual\', 3.3249e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00633333333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8595, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266488, 'I(1, 3, \'Final Residual\', 2.82322e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00637499999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8429, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266488, 'I(1, 3, \'Final Residual\', 2.37238e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00641666666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8458, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266488, 'I(1, 3, \'Final Residual\', 2.07407e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00645833333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8696, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266488, 'I(1, 3, \'Final Residual\', 1.88081e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00649999999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8517, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266488, 'I(1, 3, \'Final Residual\', 1.75833e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00654166666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8392, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266488, 'I(1, 3, \'Final Residual\', 1.66692e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00658333333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8463, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266488, 'I(1, 3, \'Final Residual\', 1.59007e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00662499999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8495, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266488, 'I(1, 3, \'Final Residual\', 1.56608e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00666666666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8479, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266488, 'I(1, 3, \'Final Residual\', 1.5797e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00670833333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8388, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266488, 'I(1, 3, \'Final Residual\', 1.59825e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266488, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00674999999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8397, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266488, 'I(1, 3, \'Final Residual\', 1.74139e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266648, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00679166666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8369, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266648, 'I(1, 3, \'Final Residual\', 2.20502e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266648, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00683333333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8483, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266648, 'I(1, 3, \'Final Residual\', 2.16833e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266648, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00687499999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8588, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266648, 'I(1, 3, \'Final Residual\', 2.59352e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266648, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00691666666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8419, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266648, 'I(1, 3, \'Final Residual\', 3.17929e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266648, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00695833333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8517, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266648, 'I(1, 3, \'Final Residual\', 3.635e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266648, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00699999999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8390, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266648, 'I(1, 3, \'Final Residual\', 4.12087e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266648, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00704166666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8500, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266648, 'I(1, 3, \'Final Residual\', 4.54376e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266648, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00708333333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8415, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266648, 'I(1, 3, \'Final Residual\', 4.93529e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266648, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00712499999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8581, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266648, 'I(1, 3, \'Final Residual\', 5.27955e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266648, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00716666666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8443, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266648, 'I(1, 3, \'Final Residual\', 5.86582e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266648, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00720833333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8369, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266652, 'I(1, 3, \'Final Residual\', 6.12285e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266652, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00724999999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8510, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266652, 'I(1, 3, \'Final Residual\', 6.31254e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266652, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00729166666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8592, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266652, 'I(1, 3, \'Final Residual\', 6.33932e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266652, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00733333333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8534, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266652, 'I(1, 3, \'Final Residual\', 6.39205e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266652, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00737499999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 3, 0, 8561, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266652, 'I(1, 3, \'Final Residual\', 1.51353e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266652, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00741666666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8528, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266652, 'I(1, 3, \'Final Residual\', 1.74793e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266652, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00745833333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8412, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266652, 'I(1, 3, \'Final Residual\', 4.75513e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266652, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00749999999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8503, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266652, 'I(1, 3, \'Final Residual\', 7.20595e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266652, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00754166666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8663, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266652, 'I(1, 3, \'Final Residual\', 1.88953e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266652, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00758333333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8645, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266652, 'I(1, 3, \'Final Residual\', 7.15956e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266652, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00762499999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8548, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266652, 'I(1, 3, \'Final Residual\', 6.109e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266652, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00766666666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8511, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266652, 'I(1, 3, \'Final Residual\', 6.26366e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266652, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00770833333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8524, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266684, 'I(1, 3, \'Final Residual\', 6.39466e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266684, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00774999999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8614, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266684, 'I(1, 3, \'Final Residual\', 6.58757e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266684, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00779166666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8537, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266684, 'I(1, 3, \'Final Residual\', 6.66182e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266684, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00783333333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8504, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266684, 'I(1, 3, \'Final Residual\', 6.50207e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266684, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00787499999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8460, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266684, 'I(1, 3, \'Final Residual\', 6.23529e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266684, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00791666666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8430, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266684, 'I(1, 3, \'Final Residual\', 5.89812e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266684, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00795833333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8585, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266684, 'I(1, 3, \'Final Residual\', 5.49272e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266684, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00799999999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8422, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266684, 'I(1, 3, \'Final Residual\', 5.19612e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266684, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00804166666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 3, 0, 8610, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266684, 'I(1, 3, \'Final Residual\', 4.98754e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266684, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00808333333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8345, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266684, 'I(1, 3, \'Final Residual\', 4.78155e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266684, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00812499999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8499, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266684, 'I(1, 3, \'Final Residual\', 4.51961e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266684, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00816666666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 2, 0, 8472, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266684, 'I(1, 3, \'Final Residual\', 4.29523e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266684, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00820833333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8466, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266684, 'I(1, 3, \'Final Residual\', 4.10727e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266684, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00824999999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8395, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266684, 'I(1, 3, \'Final Residual\', 3.91614e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266696, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00829166666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8552, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266740, 'I(1, 3, \'Final Residual\', 3.74708e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266740, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00833333333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8569, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266744, 'I(1, 3, \'Final Residual\', 3.61462e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266744, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00837499999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8477, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266744, 'I(1, 3, \'Final Residual\', 3.21333e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266744, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00841666666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8490, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266744, 'I(1, 3, \'Final Residual\', 2.67265e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266744, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00845833333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 2, 0, 8601, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266744, 'I(1, 3, \'Final Residual\', 2.2569e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266744, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00849999999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8488, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266744, 'I(1, 3, \'Final Residual\', 1.98433e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266744, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00854166666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8561, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266744, 'I(1, 3, \'Final Residual\', 1.80698e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266744, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00858333333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8588, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266744, 'I(1, 3, \'Final Residual\', 1.68977e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266744, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.008625s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8614, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266744, 'I(1, 3, \'Final Residual\', 1.58926e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266744, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00866666666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8506, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266744, 'I(1, 3, \'Final Residual\', 1.50775e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266744, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00870833333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8712, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266744, 'I(1, 3, \'Final Residual\', 1.45852e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266744, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00875s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8608, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266744, 'I(1, 3, \'Final Residual\', 1.44452e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266744, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00879166666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8438, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266744, 'I(1, 3, \'Final Residual\', 1.52683e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266744, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00883333333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8418, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266744, 'I(1, 3, \'Final Residual\', 1.78158e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266744, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.008875s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8423, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266744, 'I(1, 3, \'Final Residual\', 2.69103e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266744, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00891666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8387, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266744, 'I(1, 3, \'Final Residual\', 2.03309e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266744, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00895833333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8645, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266744, 'I(1, 3, \'Final Residual\', 2.4279e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266744, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.009s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8487, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266744, 'I(1, 3, \'Final Residual\', 3.02772e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266744, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00904166666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8474, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266744, 'I(1, 3, \'Final Residual\', 3.4659e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266744, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00908333333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8431, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266744, 'I(1, 3, \'Final Residual\', 3.92827e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266744, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.009125s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8417, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266744, 'I(1, 3, \'Final Residual\', 4.38803e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266744, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00916666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8443, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266744, 'I(1, 3, \'Final Residual\', 4.76717e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266744, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00920833333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8515, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266744, 'I(1, 3, \'Final Residual\', 5.09761e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266744, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00925s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8424, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266744, 'I(1, 3, \'Final Residual\', 5.58248e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266744, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00929166666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8569, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266744, 'I(1, 3, \'Final Residual\', 5.82537e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266744, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00933333333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8501, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266744, 'I(1, 3, \'Final Residual\', 5.98983e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266744, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00937500000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8496, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266744, 'I(1, 3, \'Final Residual\', 6.00688e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266744, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00941666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8424, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266744, 'I(1, 3, \'Final Residual\', 6.04627e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266744, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00945833333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8439, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266744, 'I(1, 3, \'Final Residual\', 1.05447e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266744, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00950000000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8498, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266744, 'I(1, 3, \'Final Residual\', 3.45149e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266744, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00954166666666668s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8514, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266744, 'I(1, 3, \'Final Residual\', 9.62415e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266744, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00958333333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8442, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266744, 'I(1, 3, \'Final Residual\', 8.78122e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266744, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00962500000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8388, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266744, 'I(1, 3, \'Final Residual\', 1.9087e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266744, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00966666666666668s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8503, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266744, 'I(1, 3, \'Final Residual\', 6.96815e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266744, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00970833333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8428, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266744, 'I(1, 3, \'Final Residual\', 5.89379e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266744, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00975000000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8497, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266744, 'I(1, 3, \'Final Residual\', 6.03666e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266748, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00979166666666668s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8375, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266760, 'I(1, 3, \'Final Residual\', 6.14521e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266764, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00983333333333335s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 2, 0, 8518, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266764, 'I(1, 3, \'Final Residual\', 6.29523e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266764, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00987500000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8565, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266764, 'I(1, 3, \'Final Residual\', 6.36192e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266764, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00991666666666668s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8440, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266764, 'I(1, 3, \'Final Residual\', 6.21851e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266764, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.00995833333333335s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8491, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266764, 'I(1, 3, \'Final Residual\', 6.00458e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266764, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.01s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8643, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266764, 'I(1, 3, \'Final Residual\', 5.67048e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266764, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0100416666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8595, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266764, 'I(1, 3, \'Final Residual\', 5.29039e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266764, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0100833333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8534, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266764, 'I(1, 3, \'Final Residual\', 4.99696e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266764, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.010125s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8567, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266764, 'I(1, 3, \'Final Residual\', 4.85934e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266764, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0101666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8230, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266764, 'I(1, 3, \'Final Residual\', 4.66202e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266764, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0102083333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8411, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266764, 'I(1, 3, \'Final Residual\', 4.43044e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266764, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.01025s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8526, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266764, 'I(1, 3, \'Final Residual\', 4.22348e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266764, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0102916666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8511, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266764, 'I(1, 3, \'Final Residual\', 4.03086e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266764, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0103333333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8376, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266764, 'I(1, 3, \'Final Residual\', 3.83212e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266764, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.010375s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8605, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266764, 'I(1, 3, \'Final Residual\', 3.66577e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266764, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0104166666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8373, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266764, 'I(1, 3, \'Final Residual\', 3.52776e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266764, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0104583333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8423, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266764, 'I(1, 3, \'Final Residual\', 3.10568e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266764, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0105s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 2, 0, 8345, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266764, 'I(1, 3, \'Final Residual\', 2.55873e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266764, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0105416666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8420, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266764, 'I(1, 3, \'Final Residual\', 2.17555e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266764, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0105833333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8437, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266764, 'I(1, 3, \'Final Residual\', 1.93298e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266764, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.010625s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8518, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266764, 'I(1, 3, \'Final Residual\', 1.76103e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266764, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0106666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8526, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266764, 'I(1, 3, \'Final Residual\', 1.64382e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266764, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0107083333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8388, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266764, 'I(1, 3, \'Final Residual\', 1.54178e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266764, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.01075s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8529, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266764, 'I(1, 3, \'Final Residual\', 1.46012e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266764, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0107916666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8545, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266764, 'I(1, 3, \'Final Residual\', 2.60372e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266764, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0108333333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8427, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266764, 'I(1, 3, \'Final Residual\', 6.58647e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266764, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.010875s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8450, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266764, 'I(1, 3, \'Final Residual\', 1.07726e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266764, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0109166666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8397, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266764, 'I(1, 3, \'Final Residual\', 9.86467e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266764, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0109583333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8427, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266764, 'I(1, 3, \'Final Residual\', 9.38565e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266764, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.011s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8583, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266764, 'I(1, 3, \'Final Residual\', 6.66063e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266764, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0110416666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8689, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266772, 'I(1, 3, \'Final Residual\', 5.94584e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266772, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0110833333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8486, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266772, 'I(1, 3, \'Final Residual\', 6.87374e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266772, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.011125s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8424, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266772, 'I(1, 3, \'Final Residual\', 7.51398e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266772, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0111666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8491, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266772, 'I(1, 3, \'Final Residual\', 6.38384e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266772, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0112083333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8427, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266772, 'I(1, 3, \'Final Residual\', 5.8888e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266772, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.01125s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8315, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266772, 'I(1, 3, \'Final Residual\', 5.72891e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266772, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0112916666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8489, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266772, 'I(1, 3, \'Final Residual\', 6.00111e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266772, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0113333333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8453, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266772, 'I(1, 3, \'Final Residual\', 5.95663e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266772, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.011375s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8443, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266772, 'I(1, 3, \'Final Residual\', 6.78483e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266772, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0114166666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8436, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266772, 'I(1, 3, \'Final Residual\', 6.76395e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266772, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0114583333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8554, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266772, 'I(1, 3, \'Final Residual\', 6.82507e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266772, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0115s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8427, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266772, 'I(1, 3, \'Final Residual\', 6.29063e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266772, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0115416666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8569, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266772, 'I(1, 3, \'Final Residual\', 1.38399e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266772, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0115833333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8558, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266772, 'I(1, 3, \'Final Residual\', 1.74397e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266772, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.011625s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8524, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266772, 'I(1, 3, \'Final Residual\', 4.85453e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266772, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0116666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8516, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266772, 'I(1, 3, \'Final Residual\', 5.051e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266772, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0117083333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8302, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266772, 'I(1, 3, \'Final Residual\', 1.52088e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266772, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.01175s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8380, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266772, 'I(1, 3, \'Final Residual\', 5.96867e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266772, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0117916666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 3, 0, 8403, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266772, 'I(1, 3, \'Final Residual\', 5.63129e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266772, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0118333333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8547, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266772, 'I(1, 3, \'Final Residual\', 5.77402e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266772, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.011875s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 2, 0, 8394, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266772, 'I(1, 3, \'Final Residual\', 5.89675e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266772, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0119166666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8446, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266772, 'I(1, 3, \'Final Residual\', 6.06012e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266772, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0119583333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8411, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266772, 'I(1, 3, \'Final Residual\', 6.08423e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266772, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.012s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8634, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266772, 'I(1, 3, \'Final Residual\', 5.95769e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266772, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0120416666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 2, 0, 8641, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266772, 'I(1, 3, \'Final Residual\', 5.72446e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266772, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0120833333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 3, 0, 8448, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266772, 'I(1, 3, \'Final Residual\', 5.3898e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266772, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.012125s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8463, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266772, 'I(1, 3, \'Final Residual\', 5.10205e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266772, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0121666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8398, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266772, 'I(1, 3, \'Final Residual\', 4.80816e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266772, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0122083333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8371, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266772, 'I(1, 3, \'Final Residual\', 4.68716e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266772, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.01225s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8616, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266772, 'I(1, 3, \'Final Residual\', 4.50216e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266772, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0122916666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8544, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266804, 'I(1, 3, \'Final Residual\', 4.3117e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266804, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0123333333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8460, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266804, 'I(1, 3, \'Final Residual\', 4.12616e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266804, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0123750000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 3, 0, 8423, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266804, 'I(1, 3, \'Final Residual\', 3.95471e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266804, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0124166666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8360, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266804, 'I(1, 3, \'Final Residual\', 3.77935e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266804, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0124583333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8495, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266804, 'I(1, 3, \'Final Residual\', 3.63097e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266804, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0125000000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8520, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266804, 'I(1, 3, \'Final Residual\', 3.50422e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266804, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0125416666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8403, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266804, 'I(1, 3, \'Final Residual\', 3.10776e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266804, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0125833333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8473, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266804, 'I(1, 3, \'Final Residual\', 2.57086e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266804, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0126250000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8402, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266804, 'I(1, 3, \'Final Residual\', 3.01121e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266804, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0126666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8587, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266804, 'I(1, 3, \'Final Residual\', 2.90575e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266804, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0127083333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8341, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266804, 'I(1, 3, \'Final Residual\', 2.86495e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266804, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0127500000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8467, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266804, 'I(1, 3, \'Final Residual\', 4.3635e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266804, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0127916666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8651, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266804, 'I(1, 3, \'Final Residual\', 8.90806e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266996, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0128333333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8645, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266996, 'I(1, 3, \'Final Residual\', 1.55158e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266996, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0128750000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8451, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266996, 'I(1, 3, \'Final Residual\', 1.8444e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266996, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0129166666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8552, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266996, 'I(1, 3, \'Final Residual\', 1.70597e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266996, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0129583333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8497, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266996, 'I(1, 3, \'Final Residual\', 1.6287e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266996, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0130000000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8545, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266996, 'I(1, 3, \'Final Residual\', 1.4734e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266996, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0130416666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8469, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266996, 'I(1, 3, \'Final Residual\', 1.34808e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266996, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0130833333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8534, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266996, 'I(1, 3, \'Final Residual\', 1.19143e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266996, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0131250000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8475, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266996, 'I(1, 3, \'Final Residual\', 1.12475e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 266996, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0131666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8597, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 266996, 'I(1, 3, \'Final Residual\', 1.15496e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267000, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0132083333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 3, 0, 8520, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267000, 'I(1, 3, \'Final Residual\', 1.36281e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267000, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0132500000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8682, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267000, 'I(1, 3, \'Final Residual\', 1.31188e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267000, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0132916666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8481, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267000, 'I(1, 3, \'Final Residual\', 1.43381e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267000, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0133333333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 2, 0, 8446, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267000, 'I(1, 3, \'Final Residual\', 1.55665e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267000, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0133750000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 2, 0, 8354, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267000, 'I(1, 3, \'Final Residual\', 1.13276e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267000, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0134166666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8519, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267000, 'I(1, 3, \'Final Residual\', 1.1497e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267000, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0134583333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8520, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267000, 'I(1, 3, \'Final Residual\', 9.42499e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267000, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0135000000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8581, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267000, 'I(1, 3, \'Final Residual\', 8.69113e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267000, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0135416666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8310, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267000, 'I(1, 3, \'Final Residual\', 7.95289e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267000, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0135833333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8421, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267000, 'I(1, 3, \'Final Residual\', 6.67449e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267000, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0136250000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 2, 0, 8344, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267000, 'I(1, 3, \'Final Residual\', 8.42749e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267000, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0136666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8430, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267000, 'I(1, 3, \'Final Residual\', 9.66307e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267000, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0137083333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8418, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267000, 'I(1, 3, \'Final Residual\', 1.96281e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267000, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0137500000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8536, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267000, 'I(1, 3, \'Final Residual\', 4.68537e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267000, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0137916666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8514, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267036, 'I(1, 3, \'Final Residual\', 1.40316e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267036, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0138333333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8434, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267036, 'I(1, 3, \'Final Residual\', 5.84231e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267036, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0138750000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8571, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267036, 'I(1, 3, \'Final Residual\', 5.61292e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267036, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0139166666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8636, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267036, 'I(1, 3, \'Final Residual\', 5.75503e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267036, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0139583333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8509, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267036, 'I(1, 3, \'Final Residual\', 5.84209e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267036, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0140000000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8466, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267036, 'I(1, 3, \'Final Residual\', 5.94654e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267036, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0140416666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8495, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267036, 'I(1, 3, \'Final Residual\', 5.93066e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267036, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0140833333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8294, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267040, 'I(1, 3, \'Final Residual\', 5.81227e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267040, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0141250000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8382, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267040, 'I(1, 3, \'Final Residual\', 5.63478e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267064, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0141666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8523, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267064, 'I(1, 3, \'Final Residual\', 5.26915e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267064, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0142083333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8515, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267064, 'I(1, 3, \'Final Residual\', 5.00936e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267064, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0142500000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8232, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267064, 'I(1, 3, \'Final Residual\', 4.75555e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267064, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0142916666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8404, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267064, 'I(1, 3, \'Final Residual\', 4.6613e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267064, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0143333333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8461, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267064, 'I(1, 3, \'Final Residual\', 4.47546e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267064, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0143750000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8381, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267064, 'I(1, 3, \'Final Residual\', 4.28833e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267064, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0144166666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8663, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267064, 'I(1, 3, \'Final Residual\', 4.09958e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267064, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0144583333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8613, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267064, 'I(1, 3, \'Final Residual\', 3.92469e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267064, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0145000000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8386, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267064, 'I(1, 3, \'Final Residual\', 3.74323e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267064, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0145416666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8457, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267064, 'I(1, 3, \'Final Residual\', 3.59577e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267064, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0145833333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8353, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267064, 'I(1, 3, \'Final Residual\', 3.46896e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267064, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0146250000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8579, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267064, 'I(1, 3, \'Final Residual\', 3.04259e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267064, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0146666666666668s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8697, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267064, 'I(1, 3, \'Final Residual\', 2.4998e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267064, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0147083333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8357, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267064, 'I(1, 3, \'Final Residual\', 2.12816e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267064, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0147500000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8488, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267064, 'I(1, 3, \'Final Residual\', 1.90791e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267064, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0147916666666668s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8385, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267064, 'I(1, 3, \'Final Residual\', 1.73812e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267064, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0148333333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8610, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267064, 'I(1, 3, \'Final Residual\', 1.63091e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267064, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0148750000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8460, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267064, 'I(1, 3, \'Final Residual\', 1.5247e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267064, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0149166666666668s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 3, 0, 8285, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267064, 'I(1, 3, \'Final Residual\', 1.42377e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267064, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0149583333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8545, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267064, 'I(1, 3, \'Final Residual\', 1.38478e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267064, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0150000000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 2, 0, 8559, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267064, 'I(1, 3, \'Final Residual\', 1.44025e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267064, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0150416666666668s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8389, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267064, 'I(1, 3, \'Final Residual\', 1.55921e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267064, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0150833333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8433, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267064, 'I(1, 3, \'Final Residual\', 2.44452e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267064, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0151250000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8558, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267064, 'I(1, 3, \'Final Residual\', 5.10491e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267064, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0151666666666668s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8594, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267064, 'I(1, 3, \'Final Residual\', 1.95599e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267084, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0152083333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8423, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 2.29514e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0152500000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8565, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 2.84845e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0152916666666668s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8589, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 3.49204e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0153333333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8583, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 3.80822e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0153750000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8521, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 4.25254e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0154166666666668s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 3, 0, 8410, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 4.7076e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0154583333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8571, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 4.88808e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0155000000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8576, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 5.387e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0155416666666668s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8588, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 5.66423e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0155833333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8568, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 5.81577e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0156250000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8488, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 5.85064e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0156666666666668s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8469, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 5.8893e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0157083333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8529, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 7.35551e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0157500000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8498, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 1.46798e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0157916666666668s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 2, 0, 8519, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 4.6524e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0158333333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8508, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 5.3817e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0158750000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8453, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 1.61333e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0159166666666668s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8506, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 6.47084e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0159583333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8365, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 5.67479e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0160000000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8640, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 5.83116e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0160416666666668s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8616, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 5.94979e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0160833333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8517, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 6.05809e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0161250000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8362, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 6.04211e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0161666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8489, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 5.91994e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0162083333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8550, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 5.6926e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0162500000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8393, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 5.34906e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0162916666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8451, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 5.0454e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0163333333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8412, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 4.74739e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0163750000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8461, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 4.63964e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0164166666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8487, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 4.45409e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0164583333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8417, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 4.27276e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0165000000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8518, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 4.08608e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0165416666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8347, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 3.91138e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0165833333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8729, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 3.73293e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0166250000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8468, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 3.58504e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0166666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8476, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 3.45541e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0167083333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8390, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 3.0335e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0167500000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8286, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 2.50025e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0167916666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8520, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 2.12784e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0168333333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8582, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 1.89826e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0168750000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8713, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 1.72947e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0169166666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 3, 0, 8618, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 1.61552e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0169583333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8427, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 1.51017e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0170000000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8316, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 1.45212e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0170416666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8622, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 2.42453e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0170833333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8586, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 4.38619e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0171250000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8570, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 1.27823e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0171666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8461, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 1.11183e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0172083333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8545, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 1.10326e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0172500000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8538, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 1.07554e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0172916666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8382, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 8.79792e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0173333333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8500, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 4.86017e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0173750000000001s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8452, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 6.86328e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0174166666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8432, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 7.85741e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0174583333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8532, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 6.85218e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0175s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8530, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 7.83088e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0175416666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8589, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 6.84677e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0175833333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8517, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 6.78983e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.017625s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 3, 0, 8581, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 6.27021e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0176666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8390, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 6.2692e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0177083333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 2, 0, 8458, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 6.77447e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.01775s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8573, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 5.84898e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0177916666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8435, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 8.31712e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0178333333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8292, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 9.98926e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.017875s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 2, 0, 8435, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 1.76462e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0179166666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8386, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 4.44324e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0179583333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8543, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 1.40016e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.018s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8434, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 5.88262e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0180416666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8444, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 5.48003e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0180833333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8537, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 5.6169e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.018125s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8591, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 5.75274e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0181666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8491, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 5.87171e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0182083333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8404, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 5.91274e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267116, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.01825s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8482, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267116, 'I(1, 3, \'Final Residual\', 5.78799e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267120, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0182916666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8513, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267120, 'I(1, 3, \'Final Residual\', 5.62012e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0183333333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8534, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 5.26176e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.018375s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8702, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 4.99188e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0184166666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8509, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 4.72231e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0184583333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8482, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 4.63769e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0185s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8656, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 4.46641e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0185416666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8383, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 4.28651e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0185833333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8419, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 4.10302e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.018625s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8376, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 3.92436e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0186666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8596, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 3.74768e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0187083333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8624, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 3.5992e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.01875s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8281, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 3.46995e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0187916666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8380, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 3.04141e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0188333333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8690, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 2.50994e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.018875s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 3, 0, 8481, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 2.13861e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0189166666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8379, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 1.91838e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0189583333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8630, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 1.79865e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.019s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8556, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 1.91501e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0190416666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8367, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 1.79674e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0190833333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8443, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 2.18997e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.019125s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8476, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 3.47692e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0191666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8481, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 4.05634e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0192083333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8392, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 5.0529e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.01925s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8395, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 6.64406e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0192916666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8554, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 8.85287e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0193333333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8525, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 8.77652e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.019375s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8349, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 8.73073e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0194166666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8590, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 7.96929e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0194583333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8489, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 5.69675e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0195s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8525, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 6.75997e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0195416666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8615, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 7.47802e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0195833333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8698, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 7.73171e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.019625s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8416, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 6.64497e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0196666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8299, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 6.62088e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0197083333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8653, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 6.39976e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.01975s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8360, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 6.09409e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0197916666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8334, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 6.01101e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0198333333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8490, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 5.94542e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.019875s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8478, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 8.10118e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0199166666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8478, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 9.81323e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0199583333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8528, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 1.98162e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.02s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8404, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 4.71189e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0200416666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8454, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 1.40735e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0200833333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8515, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 5.89383e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.020125s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8566, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 5.65781e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0201666666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8441, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 5.81272e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0202083333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8471, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 5.93564e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.02025s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8497, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 6.039e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0202916666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8482, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 5.99413e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0203333333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8491, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 5.90111e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.020375s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8343, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 5.70643e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0204166666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 2, 0, 8606, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 5.37085e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0204583333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8525, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 5.12438e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0205s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8711, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 4.79775e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0205416666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8460, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 4.66642e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0205833333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8387, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 4.47437e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.020625s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8331, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 4.28269e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0206666666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8657, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 4.08762e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0207083333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8535, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 3.91333e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.02075s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8471, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 3.73146e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0207916666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8395, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 3.58364e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0208333333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8456, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 3.45915e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.020875s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8471, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 3.03168e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0209166666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 3, 0, 8741, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 2.50046e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0209583333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8518, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 2.1264e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.021s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8593, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 1.90197e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0210416666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8575, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 1.7327e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0210833333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 3, 0, 8528, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 1.6231e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0211249999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8382, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 1.51564e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0211666666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8432, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 1.42959e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0212083333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 3, 0, 8645, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 1.37983e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0212499999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8513, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 1.39422e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0212916666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8726, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 1.50333e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0213333333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8544, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 1.68198e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0213749999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8510, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 3.86291e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0214166666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8587, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 5.66744e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0214583333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8506, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 2.253e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0214999999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8459, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 2.77106e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0215416666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8610, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 3.28352e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0215833333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8776, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 3.70071e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0216249999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8504, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 4.10441e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0216666666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8559, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 4.50119e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0217083333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8449, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 4.84451e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0217499999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8411, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 5.29536e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0217916666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8541, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 5.53689e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0218333333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8396, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 5.69639e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0218749999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8434, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 5.71369e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0219166666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8371, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 5.75915e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0219583333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8194, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 7.49605e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0219999999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8443, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 1.44608e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0220416666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8564, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 4.57619e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0220833333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8434, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 5.71497e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0221249999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 2, 0, 8492, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 1.64149e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0221666666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8434, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 6.40469e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0222083333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8431, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 5.50295e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0222499999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8442, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 5.65577e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0222916666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8632, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 5.76381e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0223333333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8589, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 5.86094e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0223749999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8331, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 5.90181e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0224166666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8679, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 5.76904e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0224583333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8362, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 5.5796e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0224999999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8507, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 5.2154e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0225416666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8557, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 4.94155e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0225833333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8508, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 4.67706e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0226249999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8504, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 4.6092e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0226666666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8483, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 4.4404e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0227083333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8622, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 4.26117e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0227499999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8419, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 4.06979e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0227916666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8314, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 3.89771e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0228333333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8675, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 3.71649e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0228749999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8646, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 3.57003e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0229166666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8474, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 3.44213e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0229583333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8378, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 3.00319e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0229999999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8361, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 2.48105e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0230416666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8456, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 2.11987e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0230833333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8357, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 1.89347e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0231249999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8333, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 1.72907e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0231666666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8671, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 1.61221e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0232083333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8578, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 1.51066e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0232499999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8630, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 1.42748e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0232916666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8750, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 1.85717e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0233333333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8544, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 3.10732e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0233749999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8433, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 4.75404e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0234166666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8565, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 7.88043e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267172, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0234583333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8434, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267172, 'I(1, 3, \'Final Residual\', 6.09678e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267516, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0234999999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8378, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267516, 'I(1, 3, \'Final Residual\', 4.77095e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267516, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0235416666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8392, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267516, 'I(1, 3, \'Final Residual\', 5.00507e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267516, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0235833333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8347, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267516, 'I(1, 3, \'Final Residual\', 5.32855e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267516, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0236249999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8377, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267516, 'I(1, 3, \'Final Residual\', 6.69729e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267524, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0236666666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8509, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267524, 'I(1, 3, \'Final Residual\', 6.173e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267524, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0237083333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8430, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267524, 'I(1, 3, \'Final Residual\', 5.02073e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267524, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0237499999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8344, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267524, 'I(1, 3, \'Final Residual\', 5.02798e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267524, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0237916666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8414, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267524, 'I(1, 3, \'Final Residual\', 6.02122e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267524, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0238333333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8373, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267524, 'I(1, 3, \'Final Residual\', 5.73033e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267524, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0238749999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8642, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267524, 'I(1, 3, \'Final Residual\', 5.96087e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267524, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0239166666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8571, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267524, 'I(1, 3, \'Final Residual\', 6.05347e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267524, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0239583333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8444, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267524, 'I(1, 3, \'Final Residual\', 6.1648e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267524, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0239999999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8519, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267524, 'I(1, 3, \'Final Residual\', 5.91874e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267524, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0240416666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8421, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267524, 'I(1, 3, \'Final Residual\', 7.20012e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267524, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0240833333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8367, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267524, 'I(1, 3, \'Final Residual\', 9.26879e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267524, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0241249999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8513, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267524, 'I(1, 3, \'Final Residual\', 1.53409e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267524, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0241666666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8480, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267524, 'I(1, 3, \'Final Residual\', 9.82166e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267548, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0242083333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8489, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267548, 'I(1, 3, \'Final Residual\', 7.79913e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267548, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0242499999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8454, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267548, 'I(1, 3, \'Final Residual\', 5.70302e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267548, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0242916666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8539, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267548, 'I(1, 3, \'Final Residual\', 5.54078e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267548, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0243333333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8630, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267548, 'I(1, 3, \'Final Residual\', 5.70012e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267548, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0243749999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8677, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267548, 'I(1, 3, \'Final Residual\', 5.82426e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267548, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0244166666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8375, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267548, 'I(1, 3, \'Final Residual\', 5.97478e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267548, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0244583333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8668, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267548, 'I(1, 3, \'Final Residual\', 6.01446e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267548, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0244999999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8742, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267548, 'I(1, 3, \'Final Residual\', 5.88675e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267548, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0245416666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8560, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267548, 'I(1, 3, \'Final Residual\', 5.69371e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267548, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0245833333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8439, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267548, 'I(1, 3, \'Final Residual\', 5.33305e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267548, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0246249999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8573, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267548, 'I(1, 3, \'Final Residual\', 5.06004e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267548, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0246666666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8543, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267548, 'I(1, 3, \'Final Residual\', 4.78718e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267548, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0247083333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8591, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267548, 'I(1, 3, \'Final Residual\', 4.65908e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267548, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0247499999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8622, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267548, 'I(1, 3, \'Final Residual\', 4.46905e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267548, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0247916666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8689, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267548, 'I(1, 3, \'Final Residual\', 4.27505e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267548, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0248333333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8624, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267548, 'I(1, 3, \'Final Residual\', 4.08644e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267548, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0248749999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8438, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267548, 'I(1, 3, \'Final Residual\', 3.91916e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267548, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0249166666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8518, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267548, 'I(1, 3, \'Final Residual\', 3.74299e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0249583333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8565, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 3.59331e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0249999999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8278, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 3.46942e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0250416666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8631, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 3.0617e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0250833333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8510, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 2.51825e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0251249999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8618, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 2.1553e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0251666666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8566, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 2.26583e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0252083333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8667, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 2.2265e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0252499999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8601, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 2.59136e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0252916666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8727, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 3.31948e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0253333333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8569, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 3.34949e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0253749999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8545, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 4.27326e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0254166666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8507, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 4.03395e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0254583333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8553, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 6.15836e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0254999999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8568, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 7.70175e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0255416666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8604, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 8.86903e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0255833333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8641, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 8.77092e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0256249999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8415, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 6.29203e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0256666666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8328, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 6.79945e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0257083333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8655, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 7.7342e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0257499999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 2, 0, 8507, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 8.2325e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0257916666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 2, 0, 8537, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 8.18337e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0258333333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8503, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 7.10929e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0258749999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8413, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 7.05763e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0259166666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8546, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 7.2252e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0259583333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8493, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 6.61141e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0259999999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8455, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 6.32667e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0260416666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8432, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 6.09477e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0260833333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8350, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 5.86826e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0261249999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8759, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 7.61896e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0261666666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8457, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 9.48172e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0262083333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8564, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 1.88283e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0262499999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8527, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 4.5221e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0262916666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8526, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 1.34438e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0263333333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8518, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 5.79574e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0263749999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8534, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 5.57883e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0264166666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8675, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 5.73027e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0264583333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8471, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 5.83547e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0264999999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8632, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 5.91322e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0265416666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8410, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 5.92125e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0265833333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8585, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 5.79356e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0266249999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8431, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 5.62137e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0266666666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8598, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 5.28079e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0267083333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8616, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 5.01289e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0267499999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8575, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267616, 'I(1, 3, \'Final Residual\', 4.73918e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267616, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0267916666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8661, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 4.65019e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0268333333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8551, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 4.47342e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0268749999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8556, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 4.28999e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0269166666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8659, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 4.10152e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0269583333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8622, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 3.92878e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0269999999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8584, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 3.74508e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0270416666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8395, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 3.59627e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0270833333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8513, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 3.4712e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0271249999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8277, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 3.04928e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0271666666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8403, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 2.5103e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0272083333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8506, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 2.14248e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0272499999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8388, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 1.91691e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0272916666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 3, 0, 8365, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 1.74879e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0273333333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8475, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 1.64456e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0273749999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8562, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 1.68123e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0274166666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 3, 0, 8533, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 1.79581e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0274583333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8392, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 6.5763e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0274999999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8396, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 1.09968e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0275416666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 3, 0, 8590, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 1.1748e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0275833333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8572, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 1.14103e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0276249999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8570, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 1.04329e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0276666666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8433, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 1.00853e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0277083333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8390, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 1.06619e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0277499999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8388, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 6.59027e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0277916666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8583, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 5.69059e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0278333333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8463, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 6.68071e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0278749999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8486, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 5.44632e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0279166666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8453, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 5.85651e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0279583333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8474, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 5.29429e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0279999999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8609, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 5.78401e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0280416666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8441, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 6.47877e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0280833333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8433, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 6.59382e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0281249999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8387, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 8.86976e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0281666666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8333, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 1.20061e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0282083333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8303, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 1.01481e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0282499999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8349, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 1.51315e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0282916666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8423, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 4.74879e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0283333333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8629, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 5.60837e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0283749999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8608, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 1.63267e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0284166666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8494, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 6.49979e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0284583333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8454, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 5.61541e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0284999999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8412, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 5.76591e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0285416666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8374, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 5.86978e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0285833333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8710, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 6.00132e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0286249999999997s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8604, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 5.99446e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0286666666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8535, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 5.88898e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0287083333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8433, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 5.67273e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0287499999999997s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8583, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 5.31112e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0287916666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8657, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 5.02766e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0288333333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8436, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 4.72915e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0288749999999997s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 2, 0, 8371, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 4.62056e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0289166666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8655, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 4.43351e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0289583333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8326, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 4.25166e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0289999999999997s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8469, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 4.06096e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0290416666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8571, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 3.8931e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0290833333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8561, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 3.71132e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0291249999999997s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8314, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 3.56236e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0291666666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8475, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 3.43802e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267628, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0292083333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8468, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267628, 'I(1, 3, \'Final Residual\', 3.01064e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0292499999999997s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8516, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 2.48225e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0292916666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8681, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 2.11577e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0293333333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8679, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 1.8899e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0293749999999997s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8507, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 1.72286e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0294166666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8368, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 1.61662e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0294583333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8429, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 1.52748e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0294999999999997s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8457, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 1.6601e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0295416666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8540, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 3.40385e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0295833333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8504, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 6.07853e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0296249999999997s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8304, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 9.69446e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0296666666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8361, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 1.02813e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0297083333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8460, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 9.01217e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0297499999999997s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8555, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 7.859e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0297916666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8419, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 9.70721e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.029833333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8389, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 7.94427e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0298749999999997s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8461, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 8.57321e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0299166666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8700, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 8.37645e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.029958333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8400, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 1.07082e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0299999999999997s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8509, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 6.31531e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0300416666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8411, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 5.4639e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.030083333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8441, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 6.37172e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0301249999999997s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8559, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 5.82985e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0301666666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8376, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 5.93519e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.030208333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8306, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 5.91027e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0302499999999997s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8583, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 5.86561e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0302916666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8561, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 7.90362e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.030333333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8494, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 9.76489e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0303749999999997s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8512, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 1.73779e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0304166666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8548, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 4.38001e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.030458333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8341, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 1.3875e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0304999999999997s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8390, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 5.84906e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0305416666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8414, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 5.47067e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.030583333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8474, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 5.59383e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0306249999999997s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8504, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 5.71651e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0306666666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8719, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 5.8552e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.030708333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8495, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 5.8738e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0307499999999997s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8352, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 5.76322e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0307916666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8449, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 5.57315e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.030833333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8438, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 5.21062e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0308749999999997s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8672, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 4.96297e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0309166666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8448, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 4.70263e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.030958333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8659, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 4.61674e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0309999999999997s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8526, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 4.43714e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0310416666666663s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8586, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 4.26728e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.031083333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8480, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 4.08034e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0311249999999997s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 2, 0, 8416, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 3.90044e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0311666666666663s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8404, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 3.73077e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.031208333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8521, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 3.58791e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0312499999999997s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8348, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 3.45854e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0312916666666663s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 3, 0, 8560, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 3.02152e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.031333333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8502, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 2.49518e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0313749999999997s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 2, 0, 8524, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 2.13216e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0314166666666663s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8684, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 1.90916e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.031458333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 2, 0, 8419, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 1.74006e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0314999999999997s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8443, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 1.67279e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0315416666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8447, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 1.62056e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.031583333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8485, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 1.49409e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0316249999999997s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 2, 0, 8636, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 1.48507e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0316666666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8712, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 1.55272e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.031708333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 2, 0, 8500, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 1.62725e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0317499999999997s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8542, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 1.82196e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0317916666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8503, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 4.69267e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.031833333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8493, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 3.30832e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0318749999999997s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8407, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 3.30081e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0319166666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8574, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 3.93607e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.031958333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8500, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 4.45446e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0319999999999997s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8590, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 4.5782e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0320416666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 2, 0, 8541, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 4.3986e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0320833333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8552, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 4.72372e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0321249999999997s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8775, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 4.98173e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0321666666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8525, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 5.36686e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0322083333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8587, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 5.73641e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0322499999999997s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8403, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 5.79007e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0322916666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8399, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 5.82674e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0323333333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8566, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 5.80524e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0323749999999997s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 2, 0, 8494, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 7.81916e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0324166666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8742, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 9.64052e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0324583333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8551, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 2.00058e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0324999999999997s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8505, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 4.73531e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0325416666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8573, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 1.41082e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0325833333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8511, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 5.84693e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0326249999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8585, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 5.63363e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0326666666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8557, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 5.77542e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0327083333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8496, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 5.91212e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0327499999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8389, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 6.04076e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0327916666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8345, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 5.97385e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0328333333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8515, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 5.88034e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0328749999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8502, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 5.67395e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0329166666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8504, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 5.31753e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0329583333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8366, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 5.04696e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0329999999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8597, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 4.77438e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0330416666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8475, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 4.65115e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0330833333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8533, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 4.45317e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0331249999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8399, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 4.26361e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0331666666666664s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8504, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 4.07721e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0332083333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8452, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 3.90347e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0332499999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8462, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 3.72548e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0332916666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8484, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 3.5733e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0333333333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8344, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 3.45313e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0333749999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8544, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 3.02556e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0334166666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8666, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267632, 'I(1, 3, \'Final Residual\', 2.48749e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267632, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0334583333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8477, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267636, 'I(1, 3, \'Final Residual\', 2.1249e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267636, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0334999999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8523, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267636, 'I(1, 3, \'Final Residual\', 1.89852e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267636, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0335416666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8502, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267636, 'I(1, 3, \'Final Residual\', 1.72973e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267636, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0335833333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8653, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267636, 'I(1, 3, \'Final Residual\', 1.62748e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267636, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0336249999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8465, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267636, 'I(1, 3, \'Final Residual\', 1.52595e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267636, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0336666666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8335, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267636, 'I(1, 3, \'Final Residual\', 1.44429e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267636, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0337083333333331s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8647, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267636, 'I(1, 3, \'Final Residual\', 1.38709e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267636, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0337499999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8599, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267636, 'I(1, 3, \'Final Residual\', 1.37352e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267636, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0337916666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8526, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267636, 'I(1, 3, \'Final Residual\', 1.44395e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267636, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0338333333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8561, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267636, 'I(1, 3, \'Final Residual\', 1.63658e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267636, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0338749999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8448, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267636, 'I(1, 3, \'Final Residual\', 2.14705e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267636, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0339166666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8495, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267636, 'I(1, 3, \'Final Residual\', 1.95917e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267636, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0339583333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8451, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267636, 'I(1, 3, \'Final Residual\', 3.8871e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267636, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0339999999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8432, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267636, 'I(1, 3, \'Final Residual\', 5.16966e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267636, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0340416666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8464, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267636, 'I(1, 3, \'Final Residual\', 5.21366e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267636, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0340833333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8336, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267636, 'I(1, 3, \'Final Residual\', 5.7983e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267636, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0341249999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8435, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267636, 'I(1, 3, \'Final Residual\', 5.96279e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267636, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0341666666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8678, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267636, 'I(1, 3, \'Final Residual\', 4.59182e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267636, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0342083333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 2, 0, 8339, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267636, 'I(1, 3, \'Final Residual\', 4.87247e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267636, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0342499999999998s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 2, 0, 8442, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267636, 'I(1, 3, \'Final Residual\', 5.30433e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267636, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0342916666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8426, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267636, 'I(1, 3, \'Final Residual\', 5.56424e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267636, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0343333333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8448, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267636, 'I(1, 3, \'Final Residual\', 5.69192e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267636, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0343749999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8456, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267636, 'I(1, 3, \'Final Residual\', 5.74627e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267636, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0344166666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8441, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267636, 'I(1, 3, \'Final Residual\', 5.77898e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267636, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0344583333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8478, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267636, 'I(1, 3, \'Final Residual\', 7.50529e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267636, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0344999999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8326, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267636, 'I(1, 3, \'Final Residual\', 1.44314e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267636, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0345416666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8479, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267636, 'I(1, 3, \'Final Residual\', 4.75188e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267636, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0345833333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8524, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267636, 'I(1, 3, \'Final Residual\', 5.38919e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267636, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0346249999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8466, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267636, 'I(1, 3, \'Final Residual\', 1.60327e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267636, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0346666666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8522, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267636, 'I(1, 3, \'Final Residual\', 6.23417e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267636, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0347083333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8298, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267636, 'I(1, 3, \'Final Residual\', 5.52227e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267636, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0347499999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8466, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267636, 'I(1, 3, \'Final Residual\', 5.67496e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0347916666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8461, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 5.76451e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0348333333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8650, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 5.88176e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0348749999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8430, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 5.89055e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0349166666666665s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8521, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 5.72951e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0349583333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8525, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 5.54371e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0349999999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 0, 0, 8575, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 5.18359e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0350416666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 2, 0, 8593, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 4.93656e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0350833333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8470, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 4.67078e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0351249999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8540, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 4.58132e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0351666666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8665, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 4.41214e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0352083333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8747, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 4.23166e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0352499999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8394, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 4.04433e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0352916666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8224, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 3.86283e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0353333333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8491, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 3.68467e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0353749999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8622, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 3.54624e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0354166666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8234, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 3.41562e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0354583333333332s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8559, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 2.96211e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0354999999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8471, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 2.45308e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0355416666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8566, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 2.09698e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0355833333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8641, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 1.87916e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0356249999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8383, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 1.71382e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0356666666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8435, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 1.59606e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0357083333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8495, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 1.48794e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0357499999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8416, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 1.40351e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0357916666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8549, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 1.79906e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0358333333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8665, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 3.13757e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0358749999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8512, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 4.99919e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0359166666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8347, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 8.91634e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0359583333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8558, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 7.05373e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0359999999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 3, 0, 8530, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 6.16925e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0360416666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8615, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 5.6504e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0360833333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8504, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 5.41196e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0361249999999999s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8454, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 6.74505e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0361666666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8577, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 6.72584e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0362083333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8510, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 5.56728e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.03625s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8481, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 5.54835e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0362916666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8384, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 6.90169e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0363333333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8482, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 6.50941e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.036375s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8456, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 5.75284e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0364166666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8557, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 5.91952e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0364583333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8320, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 6.32373e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0365s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8488, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 5.85764e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0365416666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8406, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 6.97244e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0365833333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8432, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 9.07074e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.036625s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8393, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 11, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 1.47661e-08, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0366666666666666s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8410, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 9.68745e-06, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0367083333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8433, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 7.63352e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.03675s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8361, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 5.60643e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0367916666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8406, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 5.47397e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0368333333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8381, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 5.63367e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.036875s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8313, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 5.7636e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0369166666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8361, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 5.90208e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0369583333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8472, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 5.92077e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.037s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 2, 0, 8666, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 5.84078e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0370416666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8577, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 5.66186e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0370833333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8473, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 5.30949e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.037125s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8428, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 5.03667e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267640, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0371666666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8451, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267640, 'I(1, 3, \'Final Residual\', 4.76561e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267648, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0372083333333333s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8573, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267648, 'I(1, 3, \'Final Residual\', 4.65296e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267648, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.03725s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8509, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267648, 'I(1, 3, \'Final Residual\', 4.46626e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267648, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0372916666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8445, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267648, 'I(1, 3, \'Final Residual\', 4.27943e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267648, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0373333333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 2, 0, 8423, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267648, 'I(1, 3, \'Final Residual\', 4.08854e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267648, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.037375s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8417, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267648, 'I(1, 3, \'Final Residual\', 3.92682e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267648, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0374166666666667s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 1, 0, 8365, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267648, 'I(1, 3, \'Final Residual\', 3.74722e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267648, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0374583333333334s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 0, 0, 0, 0, 8455, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267648, 'I(1, 3, \'Final Residual\', 3.60044e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 0, 0, 267648, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
			$begin 'ProfileGroup'
				MajorVer=2025
				MinorVer=2
				Name='Time - 0.0375s'
				$begin 'StartInfo'
				$end 'StartInfo'
				$begin 'TotalInfo'
					I(0, ' ')
				$end 'TotalInfo'
				GroupOptions=0
				TaskDataOptions(Memory=8)
				ProfileItem('  Matrix Solve', 1, 0, 1, 0, 8496, 'I(5, 1, \'Type\', \'DRS\', 2, \'Cores\', 4, false, 2, \'Matrix\', 19089, false, 1, \'Disk\', \'0KB\', 2, \'Calls\', 10, false)', true, true)
				ProfileItem('  Solve', 0, 0, 1, 0, 267648, 'I(1, 3, \'Final Residual\', 3.48376e-07, \'%g\')', true, true)
				ProfileItem('  Field Recovery', 0, 0, 2, 0, 267648, 'I(1, 0, \'\')', true, true)
			$end 'ProfileGroup'
		$end 'ProfileGroup'
		ProfileFootnote('I(2, 1, \'Stop Time\', \'11/01/2026 05:55:32\', 1, \'Status\', \'Normal Completion\')', 0)
	$end 'ProfileGroup'
$end 'Profile'
